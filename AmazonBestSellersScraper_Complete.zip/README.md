# Amazon Best Sellers Scraper

This project is a Python-based web scraper that uses Selenium to extract data from Amazon's Best Sellers section. The scraper logs in using user-provided credentials and collects detailed information about products in the top 10 categories. The extracted data is saved in both CSV and JSON formats.
